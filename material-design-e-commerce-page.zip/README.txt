A Pen created at CodePen.io. You can find this one at https://codepen.io/mdbootstrap/pen/qjmvoN.

 A basic design of a simple ecommerce page created with Material Design for Bootstrap