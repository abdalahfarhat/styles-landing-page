A Pen created at CodePen.io. You can find this one at https://codepen.io/jonyablonski/pen/ZYmEVo.

 A lightweight image gallery perfect for e-commerce product details.