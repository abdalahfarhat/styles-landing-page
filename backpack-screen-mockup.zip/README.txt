A Pen created at CodePen.io. You can find this one at https://codepen.io/amarilis/pen/aJVzaw.

 Prototype for a Ecommerce store screen.

Original design: https://dribbble.com/shots/3241818-E-commerce-Shop-Day-012-DailyUI