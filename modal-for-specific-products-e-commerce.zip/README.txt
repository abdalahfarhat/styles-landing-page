A Pen created at CodePen.io. You can find this one at https://codepen.io/anaarezo/pen/BRyogY.

 When you need put promotion modal or popup to specific products in your online store. Details product page view. E-commerce component. Promotions, Product Details page, Product View, Design, Specials, Offers.