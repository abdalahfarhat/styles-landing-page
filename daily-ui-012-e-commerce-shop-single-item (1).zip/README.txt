A Pen created at CodePen.io. You can find this one at https://codepen.io/juliepark/pen/aKbYVp.

 Here is a single item UI design for Nike Epic React Flyknit! All pink/pastel color scheme to match the rose color shoes! :) Hope you guys like it!