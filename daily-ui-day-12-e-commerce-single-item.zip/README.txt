A Pen created at CodePen.io. You can find this one at https://codepen.io/IAmAlexJohnson/pen/XexXgO.

 Daily UI | Day 12 | E-Commerce (Single Item)