A Pen created at CodePen.io. You can find this one at https://codepen.io/derekshirk/pen/dNLeZj.

 An experiment with a footwear focused e-commerce card layout and UI