var app = angular.module('pageApp', []);
          app.controller('imgCtrl', function($scope) {
            $scope.current = '';
        });