A Pen created at CodePen.io. You can find this one at https://codepen.io/shaikmaqsood/pen/PzVVOW.

 This is a Angular JS Product Catalog. This can be integrated with any E-commerce page.
 The Images change on click.