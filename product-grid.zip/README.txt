A Pen created at CodePen.io. You can find this one at https://codepen.io/nelsonleite/pen/RaGwba.

 Product grid/catalog inspired in [this](https://dribbble.com/shots/986548-Product-Catalog) dribbble. Experiencing/trying new grids to display products mainly in e-commerce.