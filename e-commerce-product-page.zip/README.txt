A Pen created at CodePen.io. You can find this one at https://codepen.io/sofiyashakeel/pen/EEaLxL.

 This is a UX design for a product page and again minimalism is key here so that the focus is all on the product images.