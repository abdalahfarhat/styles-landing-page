A Pen created at CodePen.io. You can find this one at https://codepen.io/Dleonheart/pen/wovvKg.

 Loading animation for e-commerce site 