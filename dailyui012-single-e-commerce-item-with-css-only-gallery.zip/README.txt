A Pen created at CodePen.io. You can find this one at https://codepen.io/baublet/pen/MyrBYG.

 A nifty little card I made for #DailyUI #012, a Single E-Commerce item. I really wanted it to incorporate a gallery, but I'm moving a lot of my tricks to CSS lately, and made this cool little gallery thinger (again, using CSS3 selectors and radio buttons) to made my gallery. Enjoy