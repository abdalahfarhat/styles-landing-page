A Pen created at CodePen.io. You can find this one at https://codepen.io/supah/pen/mPbLqp.

 https://dailyui.co/ #012

Just finished my e-commerce shop card for DailyUI challenge.
I mixed some of my old codepens in a single shot.
I know that it's not good for conversion, marketing and usability but I focused more on animations.

Love it on Dribbble to boost my ego  and complete all the 100 dailyui
https://dribbble.com/shots/2552804-Daily-UI-012-E-Commerce-Shop-Single-Item