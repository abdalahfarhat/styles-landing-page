A Pen created at CodePen.io. You can find this one at https://codepen.io/john-mantas/pen/bxmrBq.

 A concept for a product showcase for an e-commerce, design from dribbble shot of Rodrigo Ramos.